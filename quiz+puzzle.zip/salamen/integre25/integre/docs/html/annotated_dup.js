var annotated_dup =
[
    [ "ButtonImg", "structButtonImg.html", "structButtonImg" ],
    [ "GameState", "structGameState.html", "structGameState" ],
    [ "MemoryGame", "structMemoryGame.html", "structMemoryGame" ],
    [ "Question", "structQuestion.html", "structQuestion" ],
    [ "TimerBar", "structTimerBar.html", "structTimerBar" ]
];