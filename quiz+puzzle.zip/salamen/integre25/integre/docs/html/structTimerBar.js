var structTimerBar =
[
    [ "cropRect", "structTimerBar.html#aa0b7212095a6c67945ec33b067eccc60", null ],
    [ "currentTimer", "structTimerBar.html#a34cdbcf4e669a847c3a202e1da8b802f", null ],
    [ "fullTimer", "structTimerBar.html#abe76f77202dcdae81cfcf600472c9c79", null ],
    [ "maxWidth", "structTimerBar.html#a0dd1fd4f4621787108e085757c866263", null ],
    [ "position", "structTimerBar.html#a8c97107e41de336e57076ff26f741cbb", null ]
];