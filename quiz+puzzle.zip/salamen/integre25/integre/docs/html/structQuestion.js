var structQuestion =
[
    [ "answers", "structQuestion.html#aa0b3c19e84035b1220271e755e33d401", null ],
    [ "correctAnswer", "structQuestion.html#a044c79130fa70b37b0f714cc45b8c62e", null ],
    [ "question", "structQuestion.html#a9a7bddfc5e28ebee417db545cea0c1f7", null ],
    [ "used", "structQuestion.html#ad70baf935b5ba59244e522d27ddfc165", null ]
];