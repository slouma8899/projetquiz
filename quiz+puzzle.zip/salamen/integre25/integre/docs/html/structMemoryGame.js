var structMemoryGame =
[
    [ "difficulty", "structMemoryGame.html#a500cb782f02ae84169c0f365ccdae84b", null ],
    [ "dummy", "structMemoryGame.html#a81c0e4edea81f2ed1c21f83f395da2cf", null ],
    [ "flipped", "structMemoryGame.html#a194059e98c842fc51016d5f1247662f9", null ],
    [ "flipStart", "structMemoryGame.html#a83128a60383e656072df771b0305ff16", null ],
    [ "game_over", "structMemoryGame.html#a40a56227cab6df5244145388cb2a5139", null ],
    [ "grid_size", "structMemoryGame.html#a37b7674d7c893f4a1797f5226ca8b8cb", null ],
    [ "images", "structMemoryGame.html#af2350e4857f058e671fc2d6f7b8f6973", null ],
    [ "matches", "structMemoryGame.html#a8c89a6ccb0174ab45becb8aaebe38125", null ],
    [ "positions", "structMemoryGame.html#a26f440763aa11929184f10f6e807a0cc", null ],
    [ "score", "structMemoryGame.html#a5664f77360d273dbc592b9339c3695f1", null ],
    [ "selected", "structMemoryGame.html#a08576621d9acee8cfa13d906a122534a", null ],
    [ "start_time", "structMemoryGame.html#ae2262461b5b5a1c3113a5f7cd8e7ed74", null ],
    [ "tiles", "structMemoryGame.html#a9445c764e95f9c8455b57b90aa24f101", null ],
    [ "time_left", "structMemoryGame.html#a0f52c604ad8020cc35133c2e61e0b7cf", null ],
    [ "total_pairs", "structMemoryGame.html#a516deefe6f4ba0c664546b757d1710be", null ],
    [ "total_time", "structMemoryGame.html#aa3213533eb272ccb781eff5b4b749d85", null ]
];