var searchData=
[
  ['correctanswer_112',['correctAnswer',['../structQuestion.html#a044c79130fa70b37b0f714cc45b8c62e',1,'Question']]],
  ['croprect_113',['cropRect',['../structTimerBar.html#aa0b7212095a6c67945ec33b067eccc60',1,'TimerBar']]],
  ['currenttimer_114',['currentTimer',['../structTimerBar.html#a34cdbcf4e669a847c3a202e1da8b802f',1,'TimerBar']]]
];
