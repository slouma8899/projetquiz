var searchData=
[
  ['textrect_142',['textRect',['../structButtonImg.html#aca93a0c25a455b9cc8e325301a603c0c',1,'ButtonImg']]],
  ['textsurface_143',['textSurface',['../structButtonImg.html#ad5f899b4b81066cc3d37358631c74154',1,'ButtonImg']]],
  ['tiles_144',['tiles',['../structMemoryGame.html#a9445c764e95f9c8455b57b90aa24f101',1,'MemoryGame']]],
  ['time_5fleft_145',['time_left',['../structMemoryGame.html#a0f52c604ad8020cc35133c2e61e0b7cf',1,'MemoryGame']]],
  ['timeleft_146',['timeLeft',['../structGameState.html#a6a7e972eb3625f7f85d5edebda713c2d',1,'GameState']]],
  ['total_5fpairs_147',['total_pairs',['../structMemoryGame.html#a516deefe6f4ba0c664546b757d1710be',1,'MemoryGame']]],
  ['total_5ftime_148',['total_time',['../structMemoryGame.html#aa3213533eb272ccb781eff5b4b749d85',1,'MemoryGame']]]
];
