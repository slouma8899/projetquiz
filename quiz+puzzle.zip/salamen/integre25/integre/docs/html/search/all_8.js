var searchData=
[
  ['image_24',['image',['../structButtonImg.html#a8113f82225c0e767ca8bcaf560e69088',1,'ButtonImg']]],
  ['images_25',['images',['../structMemoryGame.html#af2350e4857f058e671fc2d6f7b8f6973',1,'MemoryGame']]],
  ['initialiser_5fbouton_26',['initialiser_bouton',['../header_8h.html#aa96da538833c5cc61455e18718744371',1,'initialiser_bouton(ButtonImg *btn, const char *chemin, int x, int y, const char *text, TTF_Font *font):&#160;source.c'],['../source_8c.html#aa96da538833c5cc61455e18718744371',1,'initialiser_bouton(ButtonImg *btn, const char *chemin, int x, int y, const char *text, TTF_Font *font):&#160;source.c']]],
  ['initialiser_5fenigme_27',['initialiser_enigme',['../enigme2_8c.html#ad72a206d04d96f6cb7735a8a93918c89',1,'initialiser_enigme(MemoryGame *game, const char *img_dir, int grid_size, int difficulty):&#160;enigme2.c'],['../enigme2_8h.html#ad72a206d04d96f6cb7735a8a93918c89',1,'initialiser_enigme(MemoryGame *game, const char *img_dir, int grid_size, int difficulty):&#160;enigme2.c']]],
  ['inittimerbar_28',['initTimerBar',['../header_8h.html#aed2c31a58f33ea035661374e81f0cca3',1,'initTimerBar(TimerBar *timer, const char *imagePath, int x, int y, SDL_Surface *screen):&#160;source.c'],['../source_8c.html#aed2c31a58f33ea035661374e81f0cca3',1,'initTimerBar(TimerBar *timer, const char *imagePath, int x, int y, SDL_Surface *screen):&#160;source.c']]],
  ['interpolatecolor_29',['interpolateColor',['../enigme2_8c.html#a89ca16378d350942b9c8c686bf0ae16d',1,'interpolateColor(Uint32 start, Uint32 end, float ratio):&#160;enigme2.c'],['../enigme2_8h.html#a89ca16378d350942b9c8c686bf0ae16d',1,'interpolateColor(Uint32 start, Uint32 end, float ratio):&#160;enigme2.c']]]
];
