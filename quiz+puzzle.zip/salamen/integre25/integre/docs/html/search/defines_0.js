var searchData=
[
  ['max_5fanswer_5flength_152',['MAX_ANSWER_LENGTH',['../header_8h.html#a52a1ce2323f3f0f7fb419fbf7d127156',1,'header.h']]],
  ['max_5fquestion_5flength_153',['MAX_QUESTION_LENGTH',['../header_8h.html#aec45cde66211f9951716353577a0d2be',1,'header.h']]],
  ['max_5fquestions_154',['MAX_QUESTIONS',['../header_8h.html#ab6b144f45d1f86ecd20ac04dde390430',1,'header.h']]]
];
