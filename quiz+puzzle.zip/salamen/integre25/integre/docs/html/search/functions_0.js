var searchData=
[
  ['checkanswer_89',['checkAnswer',['../header_8h.html#a738c38a929fc77ab2c51ebd067ad141e',1,'checkAnswer(Question *q, int answerIndex, GameState *state):&#160;source.c'],['../source_8c.html#a738c38a929fc77ab2c51ebd067ad141e',1,'checkAnswer(Question *q, int answerIndex, GameState *state):&#160;source.c']]],
  ['createdummysurfacedynamic_90',['CreateDummySurfaceDynamic',['../enigme2_8c.html#a1e923582708c7e577c7befa18c62fad5',1,'CreateDummySurfaceDynamic(int tile_size):&#160;enigme2.c'],['../enigme2_8h.html#a1e923582708c7e577c7befa18c62fad5',1,'CreateDummySurfaceDynamic(int tile_size):&#160;enigme2.c']]]
];
