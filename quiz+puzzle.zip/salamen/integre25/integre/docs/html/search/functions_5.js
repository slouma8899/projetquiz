var searchData=
[
  ['loadquestions_99',['loadQuestions',['../header_8h.html#a3f6d1fea2792b9cead47525ffbb1b327',1,'loadQuestions(Question questions[], const char *filename):&#160;source.c'],['../source_8c.html#a3f6d1fea2792b9cead47525ffbb1b327',1,'loadQuestions(Question questions[], const char *filename):&#160;source.c']]]
];
