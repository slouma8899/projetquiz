var searchData=
[
  ['no_5fhover_47',['NO_HOVER',['../header_8h.html#a62b531e43648308b0d367380df83ca84',1,'header.h']]],
  ['num_5fbuttons_48',['NUM_BUTTONS',['../header_8h.html#a45add6b39f5b0c0137de978b90e26b5d',1,'header.h']]]
];
