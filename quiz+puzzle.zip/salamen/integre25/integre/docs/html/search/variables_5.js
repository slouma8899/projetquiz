var searchData=
[
  ['image_124',['image',['../structButtonImg.html#a8113f82225c0e767ca8bcaf560e69088',1,'ButtonImg']]],
  ['images_125',['images',['../structMemoryGame.html#af2350e4857f058e671fc2d6f7b8f6973',1,'MemoryGame']]]
];
