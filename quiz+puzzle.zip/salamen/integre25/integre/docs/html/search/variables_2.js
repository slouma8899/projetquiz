var searchData=
[
  ['difficulty_115',['difficulty',['../structMemoryGame.html#a500cb782f02ae84169c0f365ccdae84b',1,'MemoryGame']]],
  ['dummy_116',['dummy',['../structMemoryGame.html#a81c0e4edea81f2ed1c21f83f395da2cf',1,'MemoryGame']]]
];
