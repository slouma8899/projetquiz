var searchData=
[
  ['checkanswer_2',['checkAnswer',['../header_8h.html#a738c38a929fc77ab2c51ebd067ad141e',1,'checkAnswer(Question *q, int answerIndex, GameState *state):&#160;source.c'],['../source_8c.html#a738c38a929fc77ab2c51ebd067ad141e',1,'checkAnswer(Question *q, int answerIndex, GameState *state):&#160;source.c']]],
  ['correctanswer_3',['correctAnswer',['../structQuestion.html#a044c79130fa70b37b0f714cc45b8c62e',1,'Question']]],
  ['createdummysurfacedynamic_4',['CreateDummySurfaceDynamic',['../enigme2_8c.html#a1e923582708c7e577c7befa18c62fad5',1,'CreateDummySurfaceDynamic(int tile_size):&#160;enigme2.c'],['../enigme2_8h.html#a1e923582708c7e577c7befa18c62fad5',1,'CreateDummySurfaceDynamic(int tile_size):&#160;enigme2.c']]],
  ['croprect_5',['cropRect',['../structTimerBar.html#aa0b7212095a6c67945ec33b067eccc60',1,'TimerBar']]],
  ['currenttimer_6',['currentTimer',['../structTimerBar.html#a34cdbcf4e669a847c3a202e1da8b802f',1,'TimerBar']]]
];
