var indexSectionsWithContent =
{
  0: "abcdefghilmnpqrstuw",
  1: "bgmqt",
  2: "ehms",
  3: "cefgilmru",
  4: "acdfgilmpqrstuw",
  5: "mnt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

