var searchData=
[
  ['gamestate_80',['GameState',['../structGameState.html',1,'']]]
];
