var searchData=
[
  ['tile_5fsize_157',['TILE_SIZE',['../enigme2_8h.html#a62ecd70800687eb2d625af180c4210d7',1,'enigme2.h']]],
  ['total_5fquiz_5ftime_158',['TOTAL_QUIZ_TIME',['../header_8h.html#ab53df902bc021f2c9216a63f6125fb1f',1,'header.h']]]
];
