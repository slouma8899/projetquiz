var searchData=
[
  ['game_5fover_121',['game_over',['../structMemoryGame.html#a40a56227cab6df5244145388cb2a5139',1,'MemoryGame']]],
  ['gfont_122',['gFont',['../enigme2_8h.html#a88e76957ec56f067af762125afcac25f',1,'gFont():&#160;main.c'],['../main_8c.html#a88e76957ec56f067af762125afcac25f',1,'gFont():&#160;main.c']]],
  ['grid_5fsize_123',['grid_size',['../structMemoryGame.html#a37b7674d7c893f4a1797f5226ca8b8cb',1,'MemoryGame']]]
];
