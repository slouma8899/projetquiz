var searchData=
[
  ['updateanswerbuttons_108',['updateAnswerButtons',['../header_8h.html#a147f0464d18ef9832e00be26f6e2a5ce',1,'updateAnswerButtons(ButtonImg normalButtons[], ButtonImg hoveredButtons[], const char answers[][MAX_ANSWER_LENGTH], TTF_Font *font):&#160;source.c'],['../source_8c.html#a147f0464d18ef9832e00be26f6e2a5ce',1,'updateAnswerButtons(ButtonImg normalButtons[], ButtonImg hoveredButtons[], const char answers[][MAX_ANSWER_LENGTH], TTF_Font *font):&#160;source.c']]],
  ['updategamestate_109',['updateGameState',['../header_8h.html#adc42f4e0ed57559aa9e3750bc6bca90b',1,'updateGameState(GameState *state):&#160;source.c'],['../source_8c.html#adc42f4e0ed57559aa9e3750bc6bca90b',1,'updateGameState(GameState *state):&#160;source.c']]],
  ['updatetimerbar_110',['updateTimerBar',['../header_8h.html#a084f7808efd4f3d7e1f0ea37638bf7cc',1,'updateTimerBar(TimerBar *timer, float timeRatio, SDL_Surface *screen):&#160;source.c'],['../source_8c.html#a084f7808efd4f3d7e1f0ea37638bf7cc',1,'updateTimerBar(TimerBar *timer, float timeRatio, SDL_Surface *screen):&#160;source.c']]]
];
