var searchData=
[
  ['gethoveredbuttonat_93',['getHoveredButtonAt',['../header_8h.html#a4eb8f17016a0280a69caafc65fbc07f9',1,'getHoveredButtonAt(ButtonImg buttons[], int numButtons, int mouseX, int mouseY):&#160;source.c'],['../source_8c.html#a4eb8f17016a0280a69caafc65fbc07f9',1,'getHoveredButtonAt(ButtonImg buttons[], int numButtons, int mouseX, int mouseY):&#160;source.c']]],
  ['getrandomquestion_94',['getRandomQuestion',['../header_8h.html#a6053dc51dca67fac47953d0af82d783b',1,'getRandomQuestion(Question questions[]):&#160;source.c'],['../source_8c.html#a6053dc51dca67fac47953d0af82d783b',1,'getRandomQuestion(Question questions[]):&#160;source.c']]]
];
