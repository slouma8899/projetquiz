var structGameState =
[
    [ "level", "structGameState.html#ae455adb5fd873dd748ffae2db6255f87", null ],
    [ "lives", "structGameState.html#a8f76e31197507980d51caac9fab1a055", null ],
    [ "score", "structGameState.html#a0dfc0a1d78577160646acae8a1f81a51", null ],
    [ "startTime", "structGameState.html#ad8d0af134df6223be6fe64096d87af33", null ],
    [ "timeLeft", "structGameState.html#a6a7e972eb3625f7f85d5edebda713c2d", null ]
];