var structButtonImg =
[
    [ "image", "structButtonImg.html#a8113f82225c0e767ca8bcaf560e69088", null ],
    [ "rect", "structButtonImg.html#adbdc1fc2099f2998b6a3be790c6497d1", null ],
    [ "textRect", "structButtonImg.html#aca93a0c25a455b9cc8e325301a603c0c", null ],
    [ "textSurface", "structButtonImg.html#ad5f899b4b81066cc3d37358631c74154", null ]
];