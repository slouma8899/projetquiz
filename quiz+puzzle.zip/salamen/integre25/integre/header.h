/**
 * @file header.h
 * @brief Header file for the quiz game, defining structures and function prototypes for game mechanics.
 * @author Your Name
 * @version 1.0
 */

#ifndef HEADER_H
#define HEADER_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>

/** @brief Number of buttons in the quiz game interface. */
#define NUM_BUTTONS 5
/** @brief Value indicating no button is hovered. */
#define NO_HOVER 999
/** @brief Maximum number of quiz questions. */
#define MAX_QUESTIONS 10
/** @brief Maximum length of a question string. */
#define MAX_QUESTION_LENGTH 256
/** @brief Maximum length of an answer string. */
#define MAX_ANSWER_LENGTH 100
/** @brief Total time for the quiz game in seconds. */
#define TOTAL_QUIZ_TIME 60

/**
 * @struct ButtonImg
 * @brief Represents a button with an image and optional text for the quiz game interface.
 */
typedef struct {
    SDL_Rect rect;          /**< Position and size of the button. */
    SDL_Surface *image;     /**< Image surface for the button. */
    SDL_Surface *textSurface; /**< Text surface for the button label. */
    SDL_Rect textRect;      /**< Position of the text on the button. */
} ButtonImg;

/**
 * @struct Question
 * @brief Represents a quiz question with answers and state.
 */
typedef struct {
    char question[MAX_QUESTION_LENGTH]; /**< The question text. */
    char answers[3][MAX_ANSWER_LENGTH]; /**< Array of three answer options. */
    int correctAnswer;                  /**< Index of the correct answer (0-2). */
    int used;                           /**< Flag indicating if the question has been used. */
} Question;

/**
 * @struct GameState
 * @brief Tracks the state of the quiz game, including score, lives, and time.
 */
typedef struct {
    int score;        /**< Player's current score. */
    int lives;        /**< Number of lives remaining. */
    int level;        /**< Current game level. */
    int timeLeft;     /**< Time remaining for the current question (seconds). */
    Uint32 startTime; /**< Timestamp when the current question started. */
} GameState;

/**
 * @struct TimerBar
 * @brief Represents a visual timer bar for the quiz game.
 */
typedef struct {
    SDL_Surface* fullTimer;   /**< Full timer bar image. */
    SDL_Surface* currentTimer; /**< Current timer bar image (cropped). */
    SDL_Rect position;        /**< Position and size of the timer bar. */
    SDL_Rect cropRect;        /**< Cropped portion of the timer bar to display. */
    int maxWidth;             /**< Maximum width of the timer bar. */
} TimerBar;

/**
 * @brief Determines which button is hovered over by the mouse.
 * @param buttons Array of buttons to check.
 * @param numButtons Number of buttons in the array.
 * @param mouseX X-coordinate of the mouse.
 * @param mouseY Y-coordinate of the mouse.
 * @return Index of the hovered button, or NO_HOVER if none.
 */
int getHoveredButtonAt(ButtonImg buttons[], int numButtons, int mouseX, int mouseY);

/**
 * @brief Initializes a button with an image and optional text.
 * @param btn Pointer to the button to initialize.
 * @param chemin Path to the button image file.
 * @param x X-coordinate of the button.
 * @param y Y-coordinate of the button.
 * @param text Optional text to display on the button (NULL if none).
 * @param font Font for rendering the text (NULL if no text).
 */
void initialiser_bouton(ButtonImg *btn, const char *chemin, int x, int y, const char* text, TTF_Font* font);

/**
 * @brief Updates the text on answer buttons for a quiz question.
 * @param normalButtons Array of normal-state buttons.
 * @param hoveredButtons Array of hovered-state buttons.
 * @param answers Array of answer texts.
 * @param font Font for rendering the answer text.
 */
void updateAnswerButtons(ButtonImg normalButtons[], ButtonImg hoveredButtons[], const char answers[][MAX_ANSWER_LENGTH], TTF_Font* font);

/**
 * @brief Loads quiz questions from a file.
 * @param questions Array to store the loaded questions.
 * @param filename Path to the file containing questions.
 * @return 1 if successful, 0 if the file could not be opened.
 */
int loadQuestions(Question questions[], const char* filename);

/**
 * @brief Selects a random, unused question from the question array.
 * @param questions Array of questions.
 * @return Pointer to the selected question, or NULL if none available.
 */
Question* getRandomQuestion(Question questions[]);

/**
 * @brief Checks if the selected answer is correct and updates the game state.
 * @param q Pointer to the current question.
 * @param answerIndex Index of the selected answer (0-2).
 * @param state Pointer to the game state.
 * @return 1 if the answer is correct, 0 otherwise.
 */
int checkAnswer(Question* q, int answerIndex, GameState* state);

/**
 * @brief Initializes a timer bar for the quiz game.
 * @param timer Pointer to the timer bar to initialize.
 * @param imagePath Path to the timer bar image.
 * @param x X-coordinate of the timer bar.
 * @param y Y-coordinate of the timer bar.
 * @param screen Screen surface for rendering compatibility.
 */
void initTimerBar(TimerBar* timer, const char* imagePath, int x, int y, SDL_Surface* screen);

/**
 * @brief Updates the timer bar based on the remaining time.
 * @param timer Pointer to the timer bar.
 * @param timeRatio Ratio of time remaining (0.0 to 1.0).
 * @param screen Screen surface for rendering compatibility.
 */
void updateTimerBar(TimerBar* timer, float timeRatio, SDL_Surface* screen);

/**
 * @brief Renders the timer bar to the screen.
 * @param screen Screen surface to render to.
 * @param timer Pointer to the timer bar.
 */
void renderTimerBar(SDL_Surface* screen, TimerBar* timer);

/**
 * @brief Frees resources used by the timer bar.
 * @param timer Pointer to the timer bar.
 */
void freeTimerBar(TimerBar* timer);

/**
 * @brief Updates the game state, including time and lives.
 * @param state Pointer to the game state.
 */
void updateGameState(GameState* state);

#endif // HEADER_H
