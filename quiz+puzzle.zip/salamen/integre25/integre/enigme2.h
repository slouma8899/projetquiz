/**
 * @file enigme2.h
 * @brief Header file for the memory game, defining structures and function prototypes.
 * @author Your Name
 * @version 1.0
 */

#ifndef ENIGME2_H
#define ENIGME2_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_rotozoom.h>
#include <SDL/SDL_gfxPrimitives.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

/** @brief Screen width in pixels. */
extern int SCREEN_W;
/** @brief Screen height in pixels. */
extern int SCREEN_H;
/** @brief Size of each tile in pixels. */
#define TILE_SIZE 100

/** @brief Sound effect for flipping a tile. */
extern Mix_Chunk *flipSound;
/** @brief Sound effect for matching tiles. */
extern Mix_Chunk *matchSound;
/** @brief Sound effect for mismatched tiles. */
extern Mix_Chunk *wrongSound;
/** @brief Sound effect for winning the game. */
extern Mix_Chunk *winSound;
/** @brief Sound effect for losing the game. */
extern Mix_Chunk *loseSound;
/** @brief Font used for rendering text in the game. */
extern TTF_Font *gFont;

/**
 * @brief Linearly interpolates between two colors for smooth transitions.
 * @param start The starting color in 32-bit RGB format.
 * @param end The ending color in 32-bit RGB format.
 * @param ratio The interpolation ratio (0.0 to 1.0).
 * @return The interpolated color in 32-bit RGB format.
 */
Uint32 interpolateColor(Uint32 start, Uint32 end, float ratio);

/**
 * @brief Creates a dummy surface when image loading fails.
 * @param tile_size The size of the square surface (width and height).
 * @return A pointer to the created SDL surface, or NULL on failure.
 */
SDL_Surface* CreateDummySurfaceDynamic(int tile_size);

/**
 * @struct MemoryGame
 * @brief Represents the state and resources of the memory game.
 */
typedef struct {
    int grid_size;         /**< Size of the game grid (e.g., 2 for 2x2). */
    int total_pairs;       /**< Total number of pairs to match. */
    SDL_Surface ***tiles;  /**< 2D array of tile surfaces [grid_size][grid_size]. */
    SDL_Surface **images;  /**< Array of image surfaces for tiles. */
    SDL_Rect **positions;  /**< 2D array of tile positions. */
    int **flipped;         /**< 2D array indicating flipped tiles (0 or 1). */
    Uint32 **flipStart;    /**< 2D array of flip animation start times. */
    int selected[2];       /**< Indices of selected tiles; -1 if none. */
    int matches;           /**< Number of matched pairs. */
    Uint32 start_time;     /**< Game start time in milliseconds. */
    int total_time;        /**< Total game time in seconds. */
    int time_left;         /**< Remaining time in seconds. */
    int game_over;         /**< Flag indicating if the game is over. */
    SDL_Surface *dummy;    /**< Dummy surface for missing images. */
    int score;             /**< Player's score (matches * time_left). */
    int difficulty;        /**< Difficulty level (1 = Easy, 2 = Hard, 3 = Extreme). */
} MemoryGame;

/**
 * @brief Initializes the memory game with grid size and difficulty.
 * @param game Pointer to the MemoryGame structure to initialize.
 * @param img_dir Directory path for image files.
 * @param grid_size Size of the game grid (e.g., 2 for 2x2).
 * @param difficulty Difficulty level (1, 2, or 3).
 */
void initialiser_enigme(MemoryGame *game, const char *img_dir, int grid_size, int difficulty);

/**
 * @brief Handles SDL events for the memory game (e.g., mouse clicks).
 * @param game Pointer to the MemoryGame structure.
 * @param ev Pointer to the SDL event to process.
 */
void Memory_HandleEvent(MemoryGame *game, SDL_Event *ev);

/**
 * @brief Updates the memory game state, including time and matches.
 * @param game Pointer to the MemoryGame structure.
 */
void Memory_Update(MemoryGame *game);

/**
 * @brief Renders the memory game to the screen.
 * @param game Pointer to the MemoryGame structure.
 * @param screen The SDL surface to render to.
 */
void Memory_Render(MemoryGame *game, SDL_Surface *screen);

/**
 * @brief Frees resources allocated for the memory game.
 * @param game Pointer to the MemoryGame structure to clean up.
 */
void Memory_Cleanup(MemoryGame *game);

#endif // ENIGME2_H
